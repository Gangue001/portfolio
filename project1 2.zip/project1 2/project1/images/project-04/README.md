# 项目 4 图片（预留）

未来可将封面保存为 cover.jpg。当前 HTML 尚未引用此目录；添加项目卡片时可复制项目一的 article，并将图片路径改为 images/project-04/cover.jpg。
