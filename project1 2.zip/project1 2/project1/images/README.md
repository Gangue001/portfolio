# 图片说明

所有网页图片已压缩为 WebP。

- project-01/cover.webp：Data Transparency 封面。
- project-01/process/：研究、草图、原型和最终设计。
- project-02/cover.webp：Uber Eats 封面；thumb-dial.webp、checkout.webp：从报告第 15、18 页截取的纸面原型照片。
- project-03/cover.webp：电影网站封面；user-flow.webp、wireframe.webp：从报告第 10、14 页截取的流程与线框图。

替换图片时保持文件名，或同步更新 index.html 的 src 与 data-image。WebP 需要真正转换格式，不能仅修改后缀。
原始 PDF 已单独备份，不属于网站提交目录。
